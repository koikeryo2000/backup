package util;

import org.apache.commons.lang3.RandomStringUtils;

public class NetMoneyCode {

	public String getNetMoneyCode(){
		RandomStringUtils.random(10,"012345ABCDEFGHIJKMLOPQRSTUWXYZ");

		return RandomStringUtils.random(10,"012345ABCDEFGHIJKMLOPQRSTUWXYZ");

	}





}
