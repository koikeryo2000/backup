package action;

import com.opensymphony.xwork2.ActionSupport;

public class GoManagerCreateAction extends ActionSupport {

	public String execute(){
		return SUCCESS;

	}

}
