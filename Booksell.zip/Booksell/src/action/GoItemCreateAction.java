package action;

import com.opensymphony.xwork2.ActionSupport;

public class GoItemCreateAction extends ActionSupport {

	public String execute(){
		return SUCCESS;

}
}
