package action;

import com.opensymphony.xwork2.ActionSupport;

public class GoManagerPageAction extends ActionSupport {

	public String execute(){

		String result;

		result=SUCCESS;

		return result;

	}

}
