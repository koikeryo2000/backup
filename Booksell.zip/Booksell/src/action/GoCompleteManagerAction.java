package action;

import com.opensymphony.xwork2.ActionSupport;

public class GoCompleteManagerAction extends ActionSupport  {

	public String execute(){
		return SUCCESS;
	}
}
