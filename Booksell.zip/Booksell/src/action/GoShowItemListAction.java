package action;

import com.opensymphony.xwork2.ActionSupport;

public class GoShowItemListAction extends ActionSupport {

	public String execute(){
		String result =SUCCESS;
		return result;

	}
}
