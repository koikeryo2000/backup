package action;

import com.opensymphony.xwork2.ActionSupport;

public class GoTopPageAction extends ActionSupport {
	public String execute(){
		return SUCCESS;

	}
}
