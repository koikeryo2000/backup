package action;

import com.opensymphony.xwork2.ActionSupport;

public class GoUnsubscribeAction extends ActionSupport {

	public String execute(){

		String result=SUCCESS;

		return result;

	}
}
