package action;

import com.opensymphony.xwork2.ActionSupport;

public class GoUserCreateAction extends ActionSupport {

	public String execute(){
		return SUCCESS;

	}
}
