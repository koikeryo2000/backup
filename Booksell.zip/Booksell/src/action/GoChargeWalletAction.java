package action;

import com.opensymphony.xwork2.ActionSupport;

public class GoChargeWalletAction extends ActionSupport {

	public String execute(){
		String result =SUCCESS;
		return result;
	}

}
