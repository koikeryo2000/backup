package dao;

public class Test4 {

	public static void main(String[] args) {
		int a= 10;
		int b= 100;
		int total =a-b;

		System.out.println(a-b);

		if (total<0) {
			System.out.println("０より大きい");
		}else {
			System.out.println("0より小さい");
		}

	}

}
