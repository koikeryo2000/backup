package dao;

import util.DateUtil;

public class Test2 {

	public static void main(String[] args) {


		DateUtil date = new DateUtil();

		String a =null;

		a=date.getDate();

		System.out.println(a);
	}

}
